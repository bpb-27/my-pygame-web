import asyncio
import random
import pygame
import sys

async def main():
    pygame.init()

    screen = pygame.display.set_mode((600, 400))
    clock = pygame.time.Clock()
    pygame.display.set_caption("Candy Bash!")
    score = 0
    fontSettings = pygame.font.SysFont("times new roman", 20, bold = True)
    bagHead_mSprite = pygame.image.load("CandyBash_Assets/BagHead_Sprite.png").convert_alpha()
    bagHead_mSprite = pygame.transform.scale(bagHead_mSprite, (50, 50))

    Candy_Art = pygame.image.load("CandyBash_Assets/CandyCorn1.png").convert_alpha()
    Candy_Art = pygame.transform.scale(Candy_Art, (20, 20))

    #BackDrop_1 = pygame.image.load("CandyBash_Assets/BackDrop_1.png").convert_alpha()
    #BackDrop_1 = pygame.transform.scale(BackDrop_1, (600, 400))

    player_speed = 30
    sprite_x = 0
    sprite_y = 0
    #gravity = 0.5
    gravity = 8
    jump_strength = -50 #-30
    isGrounded = True
    real_hitbox = pygame.Rect(30, 350, 35, 50) #350

    platforms = [pygame.Rect(90, 330, 100, 10), pygame.Rect(240, 290, 100, 10), pygame.Rect(400, 250, 100, 10)]
    candyList = [] #to hold 10 collectables

    for i in range(10): #place 10 candies in total
        random_x = random.randint(20,550)
        set_y = random.randint(0,3)
        if(set_y == 0):
            set_y = 320 #og: 330
        
        if(set_y == 1):
            set_y = 240 #og: 250

        if(set_y == 2):
            set_y = 280 #og: 290

        if(set_y == 3):
            set_y = 370
        
        candy_1 = pygame.Rect(random_x, set_y, 10, 10)
        candyList.append(candy_1) #did work. Why?

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            keys = pygame.key.get_pressed() #Keybinds "don't work"
            if (keys[pygame.K_LEFT] and real_hitbox.x >= 25):
                real_hitbox.x -= player_speed

            if (keys[pygame.K_RIGHT] and real_hitbox.x <= 540):
                real_hitbox.x += player_speed

            if keys[pygame.K_UP] and real_hitbox.y >= 0:
                isGrounded = False
                real_hitbox.y += jump_strength #- player_speed
                
            if(real_hitbox.y < 350):
                real_hitbox.y += gravity
                #sprite_y += gravity
                #if keys[pygame.K_DOWN] and :
                #if (keys[pygame.K_DOWN] and not real_hitbox.colliderect(platform)):
            if (keys[pygame.K_DOWN]):
                #sprite_y += player_speed
                real_hitbox.y += player_speed
                if(real_hitbox.bottom >= 350):
                    real_hitbox.bottom = 400 

            screen.fill((34, 100, 145))
            #screen.blit(BackDrop_1, (300,150))
            pygame.draw.rect(screen, (34, 100, 145), real_hitbox)
            screen.blit(bagHead_mSprite, real_hitbox)

            for platform in platforms:
                pygame.draw.rect(screen, (0, 0, 0), platform)
                if real_hitbox.colliderect(platform):
                    if real_hitbox.y <= 320:  # Falling down
                        real_hitbox.bottom = platform.top
                        #sprite_y = platform.top
                        is_grounded = True
                    elif (real_hitbox.y <= 90 and real_hitbox.y > 350):  # Jumping up
                            #is_grounded = False
                        real_hitbox.top = platform.bottom+10
                

                for candy in candyList[:]:
                    pygame.draw.rect(screen, (255, 255, 0), candy)
                    screen.blit(Candy_Art, candy) 
                    if real_hitbox.colliderect(candy):
                        candyList.remove(candy)
                        score +=1 

                score_text = fontSettings.render(f"Candies: {score}/10", True, (255, 161, 60))
                if(score ==10):
                    score_text = fontSettings.render(f"You win!", True, (255, 255, 0))
                screen.blit(score_text, (20, 20))
                pygame.display.flip()
                clock.tick(120) #fps = 120

        await asyncio.sleep(0)

pygame.quit()

asyncio.run(main())
